
#define JUCE_MODULE_AVAILABLE_juce_core 1

#include "BrowserPluginCharacteristics.h"


