// This is an auto-generated file to redirect any included
// module headers to the correct external folder.

#include "../../../../../modules/juce_audio_plugin_client/juce_audio_plugin_client.h"

