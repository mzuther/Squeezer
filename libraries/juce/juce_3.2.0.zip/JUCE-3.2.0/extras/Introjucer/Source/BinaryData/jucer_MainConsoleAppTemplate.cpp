/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic startup code for a Juce application.

  ==============================================================================
*/

APPHEADERS


//==============================================================================
int main (int argc, char* argv[])
{

    // ..your code goes here!


    return 0;
}
